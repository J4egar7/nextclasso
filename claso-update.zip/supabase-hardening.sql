-- =====================================================================
-- CLASO hardening: stock, order limits, real reviews
-- Run once in Supabase: Dashboard > SQL Editor > New query > paste > Run.
-- Safe to run more than once. Run supabase-orders-admin.sql first if you
-- have not already (it adds the admin order-status policy).
--
-- BEFORE YOU RUN THIS: open Admin > Products and check every product's
-- stock number. After this script, a product with stock 0 cannot be
-- ordered, and orders reduce stock automatically.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Order limits: stops junk and spam orders at the database itself
--    (the browser can be bypassed, the database cannot).
-- ---------------------------------------------------------------------
create or replace function public.enforce_order_limits()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  item jsonb;
  recent int;
  phone text := right(regexp_replace(coalesce(new.customer_phone, ''), '\D', '', 'g'), 10);
begin
  if new.items is null or jsonb_typeof(new.items) <> 'array' or jsonb_array_length(new.items) = 0 then
    raise exception 'An order must contain at least one item';
  end if;
  if jsonb_array_length(new.items) > 30 then
    raise exception 'Too many different items in one order';
  end if;

  for item in select * from jsonb_array_elements(new.items) loop
    if coalesce(item->>'qty', '') !~ '^[0-9]+$' or (item->>'qty')::int < 1 or (item->>'qty')::int > 20 then
      raise exception 'Each item quantity must be between 1 and 20';
    end if;
  end loop;

  -- No more than 3 orders from one phone number in 10 minutes. Only the last
  -- 10 digits are compared, so 0345-1111111, +92 345 1111111 and 03451111111
  -- all count as the same number.
  select count(*) into recent
  from public.orders o
  where right(regexp_replace(coalesce(o.customer_phone, ''), '\D', '', 'g'), 10) = phone
    and o.placed_at > now() - interval '10 minutes';
  if phone <> '' and recent >= 3 then
    raise exception 'Too many orders from this phone number. Please wait a few minutes and try again.';
  end if;

  return new;
end;
$$;

drop trigger if exists a_enforce_order_limits on public.orders;
create trigger a_enforce_order_limits
  before insert on public.orders
  for each row execute function public.enforce_order_limits();

-- ---------------------------------------------------------------------
-- 2. Stock: reject orders for more than we have, then reserve the stock.
--    Rows are locked so two customers cannot buy the last item at once.
--    Also keeps products.purchases real (used for "best selling").
-- ---------------------------------------------------------------------
create or replace function public.reserve_order_stock()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  item jsonb;
  pid text;
  qty int;
  prod record;
begin
  for item in select * from jsonb_array_elements(new.items) loop
    pid := coalesce(item->>'product_id', item->>'id');
    qty := coalesce((item->>'qty')::int, 1);
    continue when pid is null;

    select id, name, stock into prod from public.products where id::text = pid for update;
    continue when not found;

    if coalesce(prod.stock, 0) < qty then
      raise exception '% is out of stock or has fewer than % left', prod.name, qty;
    end if;

    update public.products
       set stock = stock - qty,
           purchases = coalesce(purchases, 0) + qty
     where id = prod.id;
  end loop;
  return new;
end;
$$;

drop trigger if exists b_reserve_order_stock on public.orders;
create trigger b_reserve_order_stock
  before insert on public.orders
  for each row execute function public.reserve_order_stock();

-- Cancelling an order puts its stock back; un-cancelling takes it again.
create or replace function public.adjust_stock_on_status_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  item jsonb;
  pid text;
  qty int;
  delta int;
begin
  if new.status is not distinct from old.status then return new; end if;
  if new.status = 'cancelled' and old.status is distinct from 'cancelled' then
    delta := 1;
  elsif old.status = 'cancelled' and new.status is distinct from 'cancelled' then
    delta := -1;
  else
    return new;
  end if;

  for item in select * from jsonb_array_elements(new.items) loop
    pid := coalesce(item->>'product_id', item->>'id');
    qty := coalesce((item->>'qty')::int, 1);
    continue when pid is null;
    update public.products
       set stock = greatest(coalesce(stock, 0) + delta * qty, 0),
           purchases = greatest(coalesce(purchases, 0) + delta * qty, 0)
     where id::text = pid;
  end loop;
  return new;
end;
$$;

drop trigger if exists adjust_stock_on_status_change on public.orders;
create trigger adjust_stock_on_status_change
  after update of status on public.orders
  for each row execute function public.adjust_stock_on_status_change();

-- ---------------------------------------------------------------------
-- 3. Real customer reviews (replaces the made-up testimonials).
--    Customers submit through submit_review(); nothing shows on the site
--    until an admin approves it in Admin > Reviews.
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  select format_type(a.atttypid, a.atttypmod) into t
  from pg_attribute a
  where a.attrelid = 'public.products'::regclass and a.attname = 'id' and not a.attisdropped;

  execute format($f$
    create table if not exists public.reviews (
      id uuid primary key default gen_random_uuid(),
      product_id %s not null references public.products(id) on delete cascade,
      reviewer_name text not null check (char_length(reviewer_name) between 1 and 60),
      city text check (city is null or char_length(city) <= 60),
      rating int not null check (rating between 1 and 5),
      title text check (title is null or char_length(title) <= 100),
      body text not null check (char_length(body) between 10 and 1000),
      status text not null default 'pending' check (status in ('pending','approved','rejected')),
      created_at timestamptz not null default now()
    )$f$, t);
end $$;

create index if not exists reviews_product_status_idx on public.reviews (product_id, status, created_at desc);

alter table public.reviews enable row level security;

drop policy if exists reviews_public_read on public.reviews;
create policy reviews_public_read on public.reviews
  for select to anon, authenticated
  using (status = 'approved');

drop policy if exists reviews_admin_all on public.reviews;
create policy reviews_admin_all on public.reviews
  for all to authenticated
  using (is_admin())
  with check (is_admin());

revoke all on public.reviews from anon, authenticated;
grant select (id, product_id, reviewer_name, city, rating, title, body, created_at, status)
  on public.reviews to anon, authenticated;
grant update (status) on public.reviews to authenticated;
grant delete on public.reviews to authenticated;

create or replace function public.submit_review(
  p_product_id text,
  p_name text,
  p_rating int,
  p_title text,
  p_body text,
  p_city text
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  pid_row record;
  recent int;
begin
  select id into pid_row from public.products where id::text = p_product_id;
  if not found then raise exception 'Product not found'; end if;
  if p_rating is null or p_rating < 1 or p_rating > 5 then raise exception 'Rating must be 1 to 5'; end if;
  if char_length(trim(coalesce(p_name, ''))) < 1 then raise exception 'Please enter your name'; end if;
  if char_length(trim(coalesce(p_body, ''))) < 10 then raise exception 'Please write at least 10 characters'; end if;

  -- Simple flood guard: at most 20 new reviews an hour across the shop.
  select count(*) into recent from public.reviews where created_at > now() - interval '1 hour';
  if recent >= 20 then raise exception 'Too many reviews right now. Please try again later.'; end if;

  insert into public.reviews (product_id, reviewer_name, city, rating, title, body)
  values (pid_row.id, trim(p_name), nullif(trim(coalesce(p_city, '')), ''), p_rating,
          nullif(trim(coalesce(p_title, '')), ''), trim(p_body));
end;
$$;

revoke all on function public.submit_review(text, text, int, text, text, text) from public;
grant execute on function public.submit_review(text, text, int, text, text, text) to anon, authenticated;

-- products.rating / products.reviews are now ALWAYS calculated from approved
-- reviews, never typed in by hand.
create or replace function public.refresh_product_rating()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare pid text := coalesce(new.product_id::text, old.product_id::text);
begin
  update public.products p
     set rating = coalesce((select round(avg(r.rating)::numeric, 1) from public.reviews r where r.product_id = p.id and r.status = 'approved'), 0),
         reviews = (select count(*) from public.reviews r where r.product_id = p.id and r.status = 'approved')
   where p.id::text = pid;
  return null;
end;
$$;

drop trigger if exists refresh_product_rating on public.reviews;
create trigger refresh_product_rating
  after insert or update of status, rating or delete on public.reviews
  for each row execute function public.refresh_product_rating();

-- One-off clean up: any product with no approved reviews shows no rating
-- (removes leftover demo numbers such as "812 reviews").
update public.products p
   set rating = 0, reviews = 0
 where not exists (select 1 from public.reviews r where r.product_id = p.id and r.status = 'approved');

-- ---------------------------------------------------------------------
-- 4. Newsletter: the sign-up boxes now really save emails.
--    Customers can only ADD an email through subscribe_newsletter();
--    only admins can read or delete the list.
-- ---------------------------------------------------------------------
create table if not exists public.subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null check (char_length(email) between 5 and 254),
  created_at timestamptz not null default now()
);
create unique index if not exists subscribers_email_key on public.subscribers (lower(email));

alter table public.subscribers enable row level security;
drop policy if exists subscribers_admin_all on public.subscribers;
create policy subscribers_admin_all on public.subscribers
  for all to authenticated using (is_admin()) with check (is_admin());

revoke all on public.subscribers from anon, authenticated;
grant select, delete on public.subscribers to authenticated;

create or replace function public.subscribe_newsletter(p_email text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  e text := lower(trim(coalesce(p_email, '')));
  recent int;
begin
  if e !~ '^[^@\s]+@[^@\s]+\.[^@\s]{2,}$' or char_length(e) > 254 then
    raise exception 'Please enter a valid email address';
  end if;
  -- Flood guard: at most 30 new sign-ups an hour across the shop.
  select count(*) into recent from public.subscribers where created_at > now() - interval '1 hour';
  if recent >= 30 then raise exception 'Too many sign-ups right now. Please try again later.'; end if;
  -- Already subscribed is fine: we do not reveal who is on the list.
  insert into public.subscribers (email) values (e) on conflict do nothing;
end;
$$;

revoke all on function public.subscribe_newsletter(text) from public;
grant execute on function public.subscribe_newsletter(text) to anon, authenticated;

-- ---------------------------------------------------------------------
-- 5. "Sold" counts are real: recalculated from actual (non-cancelled)
--    orders. From now on the order triggers above keep them up to date.
-- ---------------------------------------------------------------------
update public.products p
   set purchases = coalesce((
     select sum((i->>'qty')::int)
     from public.orders o, jsonb_array_elements(o.items) i
     where o.status is distinct from 'cancelled'
       and coalesce(i->>'product_id', i->>'id') = p.id::text
       and coalesce(i->>'qty', '') ~ '^[0-9]+$'
   ), 0);
