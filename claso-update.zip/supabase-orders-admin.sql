-- Run once in Supabase: Dashboard > SQL Editor > New query > paste > Run.
-- Lets a signed-in admin change an order's status from the Orders tab, and
-- makes the order history load quickly as it grows. Safe to run twice.
--
-- Uses the same is_admin() helper your existing orders_admin_read policy uses.

drop policy if exists orders_admin_update on public.orders;
create policy orders_admin_update on public.orders
  for update
  using (is_admin())
  with check (is_admin());

create index if not exists orders_placed_at_idx on public.orders (placed_at desc);
