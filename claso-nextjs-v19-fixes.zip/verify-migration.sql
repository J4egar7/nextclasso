-- ============================================================
-- CLASO — post-migration verification script
-- ============================================================
-- Run this in Supabase Dashboard → SQL Editor AFTER running both the
-- "SECURITY FIXES" and "CATALOG MIGRATION" sections of supabase-schema.sql.
--
-- Supabase's SQL editor runs a pasted script as ONE transaction, so an
-- earlier version of this script that deliberately triggered a real
-- permission error broke every check after it (Postgres aborts the
-- whole transaction on the first unhandled error). This version checks
-- privileges with has_column_privilege()/has_table_privilege() instead,
-- which report true/false without ever raising an error, so every
-- check below runs and reports regardless of what came before it.
--
-- Only check #6 makes a real call (place_order) and could genuinely
-- error if something's misconfigured — it's placed last so a problem
-- there can't hide the results of the other checks.
--
-- Safe to run any time. Check #6 inserts one harmless test order —
-- delete it afterward with the query at the very bottom.
-- ============================================================

-- 1. Catalog seeded?
select
  case when count(*) >= 55 then '✅ PASS' else '❌ FAIL' end as result,
  count(*) as product_count,
  '1. Catalog seeded (expect 55+)' as check_name
from products;

-- 2. id column is text (not uuid)?
select
  case when data_type = 'text' then '✅ PASS' else '❌ FAIL — still ' || data_type end as result,
  '2. products.id is text' as check_name
from information_schema.columns
where table_name = 'products' and column_name = 'id';

-- 3. New display columns exist?
select
  case when count(*) = 6 then '✅ PASS' else '❌ FAIL — only ' || count(*) || ' of 6 found' end as result,
  '3. New product columns exist (emoji, bg, badge, rating, reviews, old_price)' as check_name
from information_schema.columns
where table_name = 'products'
  and column_name in ('emoji','bg','badge','rating','reviews','old_price');

-- 4. anon CANNOT read manufacturing_cost — checked as a privilege lookup,
--    not by actually running a query as anon, so this can never itself
--    error out or abort the rest of the script.
select
  case when has_column_privilege('anon', 'products', 'manufacturing_cost', 'select')
       then '❌ FAIL — anon can read manufacturing_cost!'
       else '✅ PASS — anon cannot read manufacturing_cost'
  end as result,
  '4. manufacturing_cost is blocked from anon' as check_name;

-- 5. anon CAN read the public columns the storefront actually uses
select
  case when bool_and(has_column_privilege('anon', 'products', col, 'select'))
       then '✅ PASS'
       else '❌ FAIL — one or more public columns not readable by anon'
  end as result,
  '5. anon can read public product columns' as check_name
from unnest(array['id','name','brand','category','price','price_num','emoji','bg','badge','rating','reviews']) as col;

-- 6. anon cannot browse other people's orders directly. `orders` is
--    protected by an RLS policy (using is_admin()), not a hard
--    column-privilege revoke like manufacturing_cost — RLS filters
--    which ROWS come back rather than denying the query outright, so
--    this checks actual visible rows (safe, never errors) rather than
--    the base table grant, which stays broad by design and wouldn't
--    reflect whether RLS is doing its job.
set role anon;
select
  case when count(*) = 0 then '✅ PASS — anon sees 0 orders' else '❌ FAIL — anon can see ' || count(*) || ' orders!' end as result,
  '6. anon cannot read the orders table directly' as check_name
from orders;
reset role;

-- 7. Guest checkout actually saves, AND the total is server-verified.
--    This is the one check that makes a real call — if place_order()
--    itself is missing or broken, THIS is the statement that will show
--    an error, not the checks above it.
set role anon;
select
  case
    when total = (select price_num from products where id = (select id from products limit 1)) * 2
    then '✅ PASS — total matches real catalog price, not the fake 1 sent below'
    else '❌ FAIL — total was: ' || total
  end as result,
  '7. place_order() recalculates the real total server-side' as check_name
from place_order(
  'VERIFICATION TEST — safe to delete',
  'test@example.com',
  '03000000000',
  'Verification test address',
  jsonb_build_array(jsonb_build_object(
    'product_id', (select id from products limit 1),
    'name', (select name from products limit 1),
    'brand', (select brand from products limit 1),
    'price', 'PKR 1',   -- deliberately fake — should be ignored
    'qty', 2
  ))
);
reset role;

-- ============================================================
-- Cleanup: remove the test order created in check #7 above.
-- Run this separately once you've reviewed the results.
-- ============================================================
-- delete from orders where customer_name = 'VERIFICATION TEST — safe to delete';
