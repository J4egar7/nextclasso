-- ============================================================
-- CLASO — Supabase schema
-- Run this once in your Supabase project's SQL Editor
-- (Dashboard → SQL Editor → New Query → paste this → Run)
-- ============================================================

-- ── PRODUCTS ─────────────────────────────────────────────────
create table if not exists products (
  id                 text primary key default gen_random_uuid()::text,
  name               text not null,
  brand              text default '',
  category           text not null default 'Skincare',
  price              text not null,          -- display string, e.g. "PKR 4,500"
  price_num          integer not null default 0,
  old_price          text default null,      -- optional crossed-out original price, e.g. "PKR 5,500"
  manufacturing_cost integer default 0,       -- admin-only, never sent to public queries
  stock              integer default 0,
  description        text default '',
  weight             text default '',
  weight_unit        text default 'g',
  images             text[] default '{}',
  emoji              text default '',        -- shown as a placeholder visual until real photography is added
  bg                 text default '',        -- CSS gradient string used behind the emoji on cards
  badge              text default '',        -- e.g. bestseller | new | dermatologist | k-beauty | luxury | cult fav | icon
  rating             numeric(2,1) default null,
  reviews            integer default 0,
  purchases          integer default 0,
  views              integer default 0,
  created_at         timestamptz default now(),
  updated_at         timestamptz default now()
);

-- ── ADMINS ───────────────────────────────────────────────────
-- One row per authorised admin. id matches the Supabase Auth user's id.
create table if not exists admins (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text,
  created_at timestamptz default now()
);

-- ── ORDERS ───────────────────────────────────────────────────
create table if not exists orders (
  id             uuid primary key default gen_random_uuid(),
  customer_name  text not null,
  customer_email text,
  customer_phone text,
  customer_address text,
  items          jsonb not null,  -- [{product_id, name, brand, price, qty, unit_cost}, ...]
  items_total    integer not null default 0,
  delivery_fee   integer not null default 0,
  total          integer not null default 0,
  status         text default 'pending',  -- pending | confirmed | delivered | cancelled
  placed_at      timestamptz default now()
);

-- ============================================================
-- ROW LEVEL SECURITY — this is what actually enforces who can
-- read/write what. Without RLS enabled, anyone with your public
-- anon key could read/write anything.
-- ============================================================

alter table products enable row level security;
alter table admins   enable row level security;
alter table orders   enable row level security;

-- Helper: is the currently-authenticated user an admin?
create or replace function is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (select 1 from admins where id = auth.uid());
$$;

-- PRODUCTS: everyone can read; only admins can write.
-- (manufacturing_cost is a real column here, but the public storefront
-- must select specific columns, never `select *`, to avoid exposing it —
-- see the setup notes for the exact query shape to use.)
create policy "products_public_read" on products
  for select using (true);

create policy "products_admin_write" on products
  for insert with check (is_admin());
create policy "products_admin_update" on products
  for update using (is_admin());
create policy "products_admin_delete" on products
  for delete using (is_admin());

-- ADMINS: a user can only read their own row (to check their own status).
-- No client can insert/update/delete this table — manage it from the
-- Supabase dashboard's Table Editor only.
create policy "admins_self_read" on admins
  for select using (auth.uid() = id);

-- ORDERS: anyone can place an order (insert), but only admins can
-- read, update, or delete the order list.
create policy "orders_anyone_insert" on orders
  for insert with check (true);
create policy "orders_admin_read" on orders
  for select using (is_admin());
create policy "orders_admin_update" on orders
  for update using (is_admin());
create policy "orders_admin_delete" on orders
  for delete using (is_admin());

-- ============================================================
-- STORAGE — product images bucket
-- ============================================================
-- `on conflict do nothing` used to mean that if this bucket already
-- existed as private (e.g. created once before this file added public:
-- true, or created via the dashboard UI, which defaults to private),
-- re-running this never actually corrected it — the bucket just stayed
-- private with no error anywhere, which looks exactly like "uploaded
-- images don't show up" (broken image icon, no JS error, because the
-- browser gets a 400/403 fetching a private bucket's public URL).
-- `do update` fixes that going forward, whichever way it was created.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

create policy "product_images_public_read" on storage.objects
  for select using (bucket_id = 'product-images');
create policy "product_images_admin_write" on storage.objects
  for insert with check (bucket_id = 'product-images' and is_admin());
create policy "product_images_admin_delete" on storage.objects
  for delete using (bucket_id = 'product-images' and is_admin());

-- ============================================================
-- SECURITY FIXES (added after initial launch) — safe to re-run.
-- If you already ran the sections above on a live project, just run
-- this section on its own; it doesn't touch existing data.
-- ============================================================

-- Add the newer product columns first, before anything below references
-- them — a live project's `products` table may predate them. (If you're
-- running this whole file top-to-bottom on a brand-new project, the
-- `create table` above already includes these and this is a no-op.)
alter table products add column if not exists old_price text default null;
alter table products add column if not exists emoji      text default '';
alter table products add column if not exists bg         text default '';
alter table products add column if not exists badge      text default '';
alter table products add column if not exists rating     numeric(2,1) default null;
alter table products add column if not exists reviews    integer default 0;
alter table products add column if not exists purchases  integer default 0;
alter table products add column if not exists views      integer default 0;

-- ── FIX 1: manufacturing_cost was only kept private by convention ──
-- RLS policies control which ROWS a query can see, not which COLUMNS.
-- "products_public_read" is `using (true)`, so with only that policy in
-- place, anyone holding the public anon key could call
-- `select manufacturing_cost from products` directly against the
-- Supabase REST API and get it back, regardless of what columns the
-- app's own client code asks for.
--
-- Important (tested against a real Postgres instance while writing this):
-- a table-level `grant select on products to anon` — which is what
-- Supabase sets up by default — overrides any column-level revoke; you
-- cannot layer a column REVOKE on top of a table-level GRANT and have
-- it stick. The only way that actually restricts a column is to revoke
-- the table-level grant entirely and re-grant SELECT on the explicit
-- list of safe columns instead. That's what this does — anon can no
-- longer run `select *` on products at all (matches the app's own
-- public query in StoreContext.js, which already names its columns
-- explicitly, so this doesn't change app behaviour).
--
-- Note: since this app has no customer accounts (checkout is guest-only),
-- the Postgres "authenticated" role is effectively "logged-in admin" —
-- if you ever add customer sign-in, revisit this so ordinary customers
-- don't inherit admin-only column access.
revoke select on products from anon;
grant select (
  id, name, brand, category, price, price_num, old_price, stock,
  description, weight, weight_unit, images, emoji, bg, badge,
  rating, reviews, purchases, views, created_at, updated_at
) on products to anon;

revoke select on products from authenticated;
grant select on products to authenticated; -- admins: every column, including manufacturing_cost

-- ── FIX 2: order totals were trusted as sent by the browser ──
-- placeOrder() computes items_total/total in client-side JS from cart
-- state before inserting into `orders`. Anyone can edit that state (or
-- replay the network request) and submit a real product list with a
-- fabricated total. This trigger recalculates items_total/total from
-- the authoritative price_num on the products table before every
-- insert, so the stored total can't be lower (or higher) than what the
-- catalog actually charges — no client-supplied total is trusted.
--
-- Limitation: this can only verify items whose product_id exists in
-- this `products` table. Hardcoded-catalog items (the ones still only
-- in src/data/products.js, not yet migrated into Supabase) have no
-- matching row here, so their client-supplied price is still trusted
-- for now — the same hybrid-data-source gap already flagged elsewhere.
-- Once the hardcoded catalog is migrated into Supabase, every item
-- will be covered.
create or replace function recalculate_order_total()
returns trigger
language plpgsql
security definer
as $$
declare
  item        jsonb;
  matched_row products%rowtype;
  qty         integer;
  computed_items_total integer := 0;
  computed_delivery_fee integer;
  rebuilt_items jsonb := '[]'::jsonb;
begin
  for item in select * from jsonb_array_elements(new.items)
  loop
    qty := greatest(1, coalesce((item->>'qty')::integer, 1));

    select * into matched_row
    from products
    where id::text = item->>'product_id'
    limit 1;

    if found then
      -- Known product: use the real price/name from the catalog,
      -- ignoring whatever the client sent for them.
      computed_items_total := computed_items_total + (matched_row.price_num * qty);
      rebuilt_items := rebuilt_items || jsonb_build_object(
        'product_id', matched_row.id,
        'name', matched_row.name,
        'brand', matched_row.brand,
        'price', matched_row.price,
        'qty', qty,
        'bg', item->'bg',
        'emoji', item->'emoji'
      );
    else
      -- Not in this table yet (hardcoded-catalog item) — no authoritative
      -- price to check against here, so fall back to parsing the digits
      -- out of the client-supplied display price (e.g. "PKR 3,200" → 3200),
      -- the same way the app's own cartTotal is computed. This item's
      -- price still isn't verified against a source of truth — that's
      -- only fully closed once it's migrated into this table.
      computed_items_total := computed_items_total + (
        coalesce(nullif(regexp_replace(item->>'price', '[^0-9]', '', 'g'), '')::integer, 0) * qty
      );
      rebuilt_items := rebuilt_items || jsonb_build_object(
        'product_id', item->'product_id',
        'name', item->'name',
        'brand', item->'brand',
        'price', item->'price',
        'qty', qty,
        'bg', item->'bg',
        'emoji', item->'emoji'
      );
    end if;
  end loop;

  computed_delivery_fee := case when computed_items_total >= 5000 then 0 else 250 end;

  new.items        := rebuilt_items;
  new.items_total   := computed_items_total;
  new.delivery_fee  := computed_delivery_fee;
  new.total         := computed_items_total + computed_delivery_fee;

  return new;
end;
$$;

drop trigger if exists trg_recalculate_order_total on orders;
create trigger trg_recalculate_order_total
  before insert on orders
  for each row
  execute function recalculate_order_total();

-- ── FIX 3: guest checkout couldn't actually save to Supabase at all ──
-- Tested directly against Postgres while writing this fix: with only
-- "orders_anyone_insert" (INSERT) and "orders_admin_read" (SELECT,
-- admins only) in place, an unauthenticated customer's
-- `.insert({...}).select()` — which is exactly what the app's
-- placeOrder() does — fails outright. Under RLS, INSERT ... RETURNING
-- requires the inserting role to be able to read back the row it just
-- wrote; anon has no SELECT policy on orders at all, so Postgres
-- rejects the whole statement and nothing is saved. Every guest order
-- was silently falling back to localStorage-only, meaning admins never
-- actually saw any real customer orders in Supabase.
--
-- The tempting quick fix — a permissive SELECT policy for anon — would
-- let any visitor read every customer's name, phone, and address, so
-- that's not an option. Instead, this function performs the insert
-- itself (as its owner, bypassing RLS the same safe way is_admin()
-- already does elsewhere in this file) and returns only the one order
-- just created, never anyone else's. The app should call this via
-- `supabase.rpc("place_order", {...})` instead of inserting into the
-- table directly.
create or replace function place_order(
  p_customer_name    text,
  p_customer_email   text,
  p_customer_phone   text,
  p_customer_address text,
  p_items            jsonb
)
returns table (
  id            uuid,
  items         jsonb,
  items_total   integer,
  delivery_fee  integer,
  total         integer,
  placed_at     timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  new_row orders%rowtype;
begin
  insert into orders (customer_name, customer_email, customer_phone, customer_address, items)
  values (p_customer_name, p_customer_email, p_customer_phone, p_customer_address, p_items)
  returning * into new_row;
  -- items/items_total/delivery_fee/total on new_row are already the
  -- server-recalculated values from trg_recalculate_order_total, which
  -- fires as part of this INSERT — so what's returned below is the
  -- verified total, not whatever the client originally sent.

  return query select new_row.id, new_row.items, new_row.items_total,
                      new_row.delivery_fee, new_row.total, new_row.placed_at;
end;
$$;

grant execute on function place_order(text, text, text, text, jsonb) to anon, authenticated;

-- ============================================================
-- CATALOG MIGRATION (added when the hardcoded product catalog was
-- retired) — safe to re-run. Brings an existing live project's
-- `products` table up to the shape the app now expects, then seeds it
-- with the products that used to live in src/data/products.js.
-- (The new columns these products need — emoji, bg, badge, rating, etc.
-- — are added by the SECURITY FIXES section above; run that first if
-- you haven't already.)
-- ============================================================

-- The old catalog used small human-readable ids ("1", "2", ...); those
-- are seeded below as literal ids so the product URLs already indexed
-- by the sitemap keep working. If this table was created before this
-- migration, its `id` column is `uuid` and can't hold those — widen it
-- to `text` first. Existing uuid values are preserved as their text
-- form, so any admin-added products and any orders referencing them by
-- id are unaffected.
do $$
begin
  if (select data_type from information_schema.columns
      where table_name = 'products' and column_name = 'id') = 'uuid' then
    alter table products alter column id drop default;
    alter table products alter column id type text using id::text;
    alter table products alter column id set default gen_random_uuid()::text;
  end if;
end $$;

-- Seed the former hardcoded catalog (auto-generated from the original
-- src/data/products.js, all 55 products). The 4 original homepage-only
-- products had no category/description in the source data, so they've
-- been assigned a sensible category here and left with an empty
-- description (same as they had before). `on conflict do nothing` makes
-- this safe to re-run -- it will never overwrite a product you've since
-- edited, or a same-id row that already exists.
insert into products
  (id, name, brand, category, price, price_num, old_price, stock, description,
   emoji, bg, badge, rating, reviews, purchases, views)
values
  ('1', 'Water Sleeping Mask', 'LANEIGE', 'Masks', 'PKR 3,200', 3200, 'PKR 4,100', 100, '', '🌸', 'linear-gradient(135deg,#FFD6E7,#FFACC7)', 'bestseller', 4.9, 812, 0, 0),
  ('2', 'AHA BHA PHA Toner', 'SOME BY MI', 'Toners', 'PKR 2,800', 2800, 'PKR 3,500', 100, '', '🌿', 'linear-gradient(135deg,#D4F5E9,#A8E6CF)', 'new', 4.8, 634, 0, 0),
  ('3', 'Pro Filt''r Foundation', 'FENTY BEAUTY', 'Face', 'PKR 6,500', 6500, 'PKR 8,200', 100, '', '✨', 'linear-gradient(135deg,#FFE0CC,#FFAB73)', 'bestseller', 4.9, 1024, 0, 0),
  ('4', 'Pillow Talk Lipstick', 'CHARLOTTE T.', 'Lips', 'PKR 4,100', 4100, null, 100, '', '💄', 'linear-gradient(135deg,#F8C8D4,#F4A0B5)', 'new', 4.7, 523, 0, 0),
  ('10', 'Hydrating Facial Cleanser', 'CERAVE', 'Cleansers', 'PKR 1,800', 1800, null, 100, 'Gentle non-foaming cleanser with ceramides for normal to dry skin', '🌙', 'linear-gradient(135deg,#E8D5F5,#C9A8F0)', 'bestseller', 4.9, 2103, 8400, 32000),
  ('16', 'Toleriane Hydrating Cleanser', 'LA ROCHE-POSAY', 'Cleansers', 'PKR 2,400', 2400, null, 100, 'Ultra-gentle cleanser for sensitive and reactive skin types', '🫧', 'linear-gradient(135deg,#E0F2FE,#BAE6FD)', 'dermatologist', 4.8, 1540, 5200, 19000),
  ('17', 'Soy Face Cleanser', 'FRESH', 'Cleansers', 'PKR 4,200', 4200, null, 100, 'Award-winning gel-cream cleanser that removes makeup effortlessly', '🍑', 'linear-gradient(135deg,#FFDBB4,#FFC090)', null, 4.7, 980, 3100, 14000),
  ('18', 'Green Tea Foam Cleanser', 'INNISFREE', 'Cleansers', 'PKR 1,600', 1600, null, 100, 'Jeju green tea foam that gently purifies and calms the skin', '🌊', 'linear-gradient(135deg,#D1FAE5,#A7F3D0)', 'k-beauty', 4.6, 720, 2800, 11000),
  ('11', 'Hyaluronic Acid 2% + B5', 'THE ORDINARY', 'Serums', 'PKR 1,200', 1200, null, 100, 'Multi-weight HA with B5 for intense surface and below-surface hydration', '💧', 'linear-gradient(135deg,#D4E8FF,#A8CAFE)', 'cult fav', 4.8, 1876, 9200, 41000),
  ('12', 'The Dewy Serum', 'TATCHA', 'Serums', 'PKR 9,800', 9800, null, 100, 'Plumping bouncy serum with hyaluronic acid and leopard lily', '🌺', 'linear-gradient(135deg,#FFD6E7,#FFC2D4)', 'luxury', 4.9, 945, 2100, 18000),
  ('19', 'C E Ferulic Serum', 'SKINCEUTICALS', 'Serums', 'PKR 14,500', 14500, null, 100, 'Iconic vitamin C serum that neutralises free radicals and visibly firms skin', '⚗️', 'linear-gradient(135deg,#FFF9C4,#FFF176)', 'luxury', 5, 1120, 1800, 22000),
  ('20', 'T.L.C. Framboos Serum', 'DRUNK ELEPHANT', 'Serums', 'PKR 11,200', 11200, null, 100, 'Glycolic/lactic/tartaric/citric and salicylic acid blend for resurfacing', '🌹', 'linear-gradient(135deg,#FCE4EC,#F48FB1)', null, 4.7, 840, 2400, 17000),
  ('21', '10% Niacinamide Booster', 'PAULA''S CHOICE', 'Serums', 'PKR 3,600', 3600, null, 100, 'Concentrated niacinamide serum visibly reduces pores and uneven skin tone', '🔬', 'linear-gradient(135deg,#E8EAF6,#C5CAE9)', 'new', 4.8, 1320, 4700, 26000),
  ('22', 'Crème de la Mer', 'LA MER', 'Moisturisers', 'PKR 28,000', 28000, null, 100, 'Legendary sea kelp Miracle Broth moisturiser for ultimate skin transformation', '🏔️', 'linear-gradient(135deg,#B2EBF2,#80DEEA)', 'luxury', 4.9, 780, 900, 15000),
  ('23', 'Hydro Boost Water Gel', 'NEUTROGENA', 'Moisturisers', 'PKR 2,800', 2800, null, 100, 'Hyaluronic acid gel-cream that continuously releases hydration', '💦', 'linear-gradient(135deg,#E0F7FA,#B2EBF2)', 'bestseller', 4.8, 3200, 11000, 48000),
  ('24', 'Ultra Repair Cream', 'FIRST AID BEAUTY', 'Moisturisers', 'PKR 3,400', 3400, null, 100, 'Intense hydration for dry, distressed skin with colloidal oatmeal', '🌾', 'linear-gradient(135deg,#F3E5D8,#E8D5C4)', null, 4.7, 1880, 5600, 21000),
  ('25', 'First Care Activating Serum', 'SULWHASOO', 'Moisturisers', 'PKR 8,400', 8400, null, 100, 'Herbal Korean essence that activates skin''s natural renewal cycle', '🫐', 'linear-gradient(135deg,#EDE7F6,#D1C4E9)', 'k-beauty', 4.8, 620, 1400, 9800),
  ('13', 'Heartleaf Quercetinol SPF 50+', 'ANUA', 'SPF', 'PKR 2,400', 2400, null, 100, 'Lightweight calming sunscreen with zero white cast — K-beauty darling', '☀️', 'linear-gradient(135deg,#FFFDE7,#FFF59D)', 'k-beauty', 4.8, 1523, 6800, 35000),
  ('26', 'Hyaluronic Acid Watery Sun Gel', 'ISNTREE', 'SPF', 'PKR 2,100', 2100, null, 100, 'Water gel SPF 50+ that melts into skin with no greasiness whatsoever', '🌅', 'linear-gradient(135deg,#FFF8E1,#FFECB3)', 'new', 4.7, 890, 3400, 18000),
  ('27', 'Unseen Sunscreen SPF 40', 'SUPERGOOP!', 'SPF', 'PKR 5,200', 5200, null, 100, 'Invisible gel-formula SPF that doubles as a makeup primer', '🛡️', 'linear-gradient(135deg,#F3F4F6,#E5E7EB)', null, 4.6, 1100, 2900, 22000),
  ('14', 'Lip Sleeping Mask', 'LANEIGE', 'Masks', 'PKR 2,200', 2200, null, 100, 'Overnight lip treatment with sweet vitamin complex for plump morning lips', '🍯', 'linear-gradient(135deg,#FFE0B2,#FFCC80)', 'bestseller', 5, 3012, 12000, 55000),
  ('28', 'Facial Treatment Mask', 'SK-II', 'Masks', 'PKR 6,800', 6800, null, 100, 'Pitera-drenched sheet mask delivering 10 years of luminosity in 15 minutes', '🎭', 'linear-gradient(135deg,#E8EAF6,#9FA8DA)', 'luxury', 4.9, 1240, 2200, 19000),
  ('29', 'Watermelon Glow Sleeping Mask', 'GLOW RECIPE', 'Masks', 'PKR 4,600', 4600, null, 100, 'Overnight AHA exfoliating mask with hyaluronic acid for glass skin', '🌋', 'linear-gradient(135deg,#FCE4EC,#EF9A9A)', null, 4.7, 760, 2800, 16000),
  ('30', 'Luminance Eye Cream', 'TATCHA', 'Eye Care', 'PKR 7,200', 7200, null, 100, 'Powerful brightening eye cream with Japanese superfoods for dark circles', '👁️', 'linear-gradient(135deg,#F8BBD9,#F48FB1)', null, 4.6, 430, 1100, 8400),
  ('31', 'Banana Bright Eye Crème', 'OLEHENRIKSEN', 'Eye Care', 'PKR 3,800', 3800, null, 100, 'Vitamin C and banana powder blend to colour-correct and brighten instantly', '✨', 'linear-gradient(135deg,#FFFDE7,#FFF176)', 'new', 4.7, 560, 1800, 12000),
  ('15', 'Green Tea Balancing Toner', 'INNISFREE', 'Toners', 'PKR 2,600', 2600, null, 100, 'Antioxidant-rich toner from Jeju green tea to balance and refine pores', '🌿', 'linear-gradient(135deg,#E8F5E9,#C8E6C9)', 'k-beauty', 4.7, 887, 3100, 15000),
  ('32', 'AHA BHA PHA 30 Days Miracle Toner', 'SOME BY MI', 'Toners', 'PKR 2,800', 2800, null, 100, 'Triple acid toner visibly transforms acne-prone skin in 30 days', '🌸', 'linear-gradient(135deg,#FCE4EC,#F8BBD9)', 'cult fav', 4.8, 2340, 7600, 38000),
  ('33', 'Advanced Snail 96 Mucin Toner', 'COSRX', 'Toners', 'PKR 3,100', 3100, null, 100, '96% snail secretion filtrate toner for intense repair and hydration', '💎', 'linear-gradient(135deg,#E8EAF6,#C5CAE9)', 'bestseller', 4.9, 1860, 6900, 32000),
  ('34', '100% Organic Rosehip Seed Oil', 'THE ORDINARY', 'Oils', 'PKR 1,800', 1800, null, 100, 'Cold-pressed rosehip oil rich in omega fatty acids for scar fading and glow', '🫒', 'linear-gradient(135deg,#FFCCBC,#FFAB91)', null, 4.6, 1240, 4200, 21000),
  ('35', 'Virgin Marula Luxury Face Oil', 'DRUNK ELEPHANT', 'Oils', 'PKR 8,600', 8600, null, 100, 'Potent, fast-absorbing marula oil for lasting hydration and luminosity', '🌻', 'linear-gradient(135deg,#FFF9C4,#FFF176)', 'luxury', 4.8, 680, 1600, 11000),
  ('50', 'Gloss Bomb Universal Lip', 'FENTY BEAUTY', 'Lips', 'PKR 3,800', 3800, null, 100, 'Explosive shine + colour in a universal peachy nude for all skin tones', '👄', 'linear-gradient(135deg,#FFB3C6,#FF6B9D)', 'bestseller', 4.9, 4200, 16000, 72000),
  ('51', 'Pillow Talk Lipstick', 'CHARLOTTE TILBURY', 'Lips', 'PKR 4,100', 4100, null, 100, 'The universally flattering rosy-nude lipstick in creamy matte finish', '🌹', 'linear-gradient(135deg,#F8C8D4,#F4A0B5)', 'icon', 4.9, 5600, 18000, 85000),
  ('52', 'Retro Matte Lipstick — Ruby Woo', 'MAC', 'Lips', 'PKR 2,800', 2800, null, 100, 'Iconic retro matte formula — the most famous red lip in beauty history', '💋', 'linear-gradient(135deg,#FFCDD2,#EF9A9A)', 'icon', 4.8, 3800, 12000, 61000),
  ('53', 'Lip Maestro Velvet Lip', 'ARMANI BEAUTY', 'Lips', 'PKR 5,400', 5400, null, 100, 'Velvety liquid lip in a range of couture-inspired shades', '✨', 'linear-gradient(135deg,#E8D5F5,#CE93D8)', null, 4.7, 920, 2800, 14000),
  ('54', 'Addict Lip Glow Oil', 'DIOR BEAUTY', 'Lips', 'PKR 6,200', 6200, null, 100, 'Glossy tinted lip oil with cherry oil for plumped, nourished lips', '🍒', 'linear-gradient(135deg,#FFCDD2,#F48FB1)', 'new', 4.8, 1480, 4200, 28000),
  ('55', 'Norvina Pro Pigment Palette', 'ABH', 'Eyes', 'PKR 7,200', 7200, null, 100, 'Ultra-pigmented pressed powder eyeshadow palette with transition shades', '🎭', 'linear-gradient(135deg,#B3D9FF,#6DB8FF)', 'limited', 4.9, 2800, 6400, 38000),
  ('56', 'Naked3 Eyeshadow Palette', 'URBAN DECAY', 'Eyes', 'PKR 8,800', 8800, null, 100, '12 rosy and smoky neutrals with Rose Gold highlight and deep plum', '🦋', 'linear-gradient(135deg,#FCE4EC,#F8BBD9)', 'bestseller', 4.8, 3400, 7200, 44000),
  ('57', 'BADgal BANG Mascara', 'BENEFIT', 'Eyes', 'PKR 3,200', 3200, null, 100, 'Volumising mascara with aerospace-derived formula for 36-hour wear', '🖤', 'linear-gradient(135deg,#212121,#424242)', 'bestseller', 4.7, 4100, 14000, 58000),
  ('58', 'Pillow Talk Push Up Lashes Mascara', 'CHARLOTTE TILBURY', 'Eyes', 'PKR 3,600', 3600, null, 100, 'Curved wand lifts and curls for doe-eyed, fanned-out lashes', '🌟', 'linear-gradient(135deg,#F3E5F5,#CE93D8)', 'new', 4.6, 1220, 3900, 22000),
  ('59', 'Brow Wiz Micro-Pencil', 'ANASTASIA BH', 'Eyes', 'PKR 2,900', 2900, null, 100, 'Ultra-slim retractable brow pencil for natural, hair-like strokes', '✏️', 'linear-gradient(135deg,#D7CCC8,#BCAAA4)', 'cult fav', 4.9, 5200, 19000, 78000),
  ('60', 'Pro Filt''r Soft Matte Foundation', 'FENTY BEAUTY', 'Face', 'PKR 6,500', 6500, null, 100, 'Buildable medium-to-full coverage matte foundation in 50 inclusive shades', '🌟', 'linear-gradient(135deg,#FFE0CC,#FFAB73)', 'bestseller', 4.9, 7200, 22000, 98000),
  ('61', 'Magic Foundation', 'CHARLOTTE TILBURY', 'Face', 'PKR 8,900', 8900, null, 100, 'Award-winning micro-blurring foundation that fades fine lines and pores', '🏔️', 'linear-gradient(135deg,#FFDDE7,#FFB3CB)', 'luxury', 4.8, 2100, 5800, 34000),
  ('62', 'Sheer Glow Foundation', 'NARS', 'Face', 'PKR 5,800', 5800, null, 100, 'Weightless natural finish foundation with buildable skin-like coverage', '☁️', 'linear-gradient(135deg,#F5F5F5,#EEEEEE)', null, 4.7, 2800, 8400, 42000),
  ('63', 'All Nighter Setting Spray', 'URBAN DECAY', 'Face', 'PKR 4,400', 4400, null, 100, '16-hour makeup lock technology in matte finish — no budge, no fade', '✨', 'linear-gradient(135deg,#E8EAF6,#C5CAE9)', 'cult fav', 4.8, 4600, 15000, 64000),
  ('64', 'Born This Way Setting Powder', 'TOO FACED', 'Face', 'PKR 3,900', 3900, null, 100, 'Micro-fine translucent powder with coconut water and rice starch', '🌸', 'linear-gradient(135deg,#FCE4EC,#F8BBD9)', 'new', 4.6, 1400, 4200, 24000),
  ('65', 'Nail Lacquer — Infinite Shine', 'OPI', 'Nails', 'PKR 2,100', 2100, null, 100, 'Up to 11 days of chip-resistant, high-shine wear — no lamp needed', '💅', 'linear-gradient(135deg,#CE93D8,#BA68C8)', 'bestseller', 4.7, 3100, 10000, 45000),
  ('66', 'Gel Couture Nail Polish', 'ESSIE', 'Nails', 'PKR 1,800', 1800, null, 100, 'Two-step gel couture system for 14-day wear in 60 fashion-forward shades', '💜', 'linear-gradient(135deg,#E8EAF6,#9FA8DA)', null, 4.5, 1800, 5600, 26000),
  ('67', 'Miracle Gel Top Coat', 'SALLY HANSEN', 'Nails', 'PKR 1,200', 1200, null, 100, 'No-UV gel top coat that delivers 14-day glossy durability', '🌈', 'linear-gradient(135deg,#E1F5FE,#B3E5FC)', null, 4.4, 2200, 7200, 31000),
  ('68', 'Blush in Orgasm', 'NARS', 'Cheeks', 'PKR 5,600', 5600, null, 100, 'The legendary peachy-pink shimmer blush — a universal flattery icon', '💎', 'linear-gradient(135deg,#FFCBA4,#FF9A62)', 'icon', 4.9, 6800, 21000, 92000),
  ('69', 'Dandelion Blush', 'BENEFIT', 'Cheeks', 'PKR 3,800', 3800, null, 100, 'Sheer baby-pink blush for a fresh, flushed complexion', '🌺', 'linear-gradient(135deg,#FCE4EC,#F48FB1)', null, 4.7, 1900, 5400, 28000),
  ('70', 'Ambient Lighting Blush', 'HOURGLASS', 'Cheeks', 'PKR 6,400', 6400, null, 100, 'Luminous blush that bathes skin in warm, flattering light', '🫦', 'linear-gradient(135deg,#FFCCBC,#FFAB91)', 'luxury', 4.8, 940, 2200, 18000),
  ('71', 'Photo Finish Primer', 'SMASHBOX', 'Primers', 'PKR 3,200', 3200, null, 100, 'Silicone-based primer that blurs pores and extends foundation up to 8 hours', '🔮', 'linear-gradient(135deg,#EDE7F6,#B39DDB)', 'bestseller', 4.6, 2800, 9000, 38000),
  ('72', 'Porefessional Face Primer', 'BENEFIT', 'Primers', 'PKR 2,800', 2800, null, 100, 'Bestselling pore-minimising primer that creates a smooth base instantly', '💡', 'linear-gradient(135deg,#FFF9C4,#FFF176)', 'bestseller', 4.7, 4100, 13000, 56000),
  ('73', 'F80 Flat Kabuki Brush', 'SIGMA BEAUTY', 'Tools', 'PKR 3,400', 3400, null, 100, 'Award-winning flat top kabuki for seamless foundation blending', '🖌️', 'linear-gradient(135deg,#F5F5F5,#E0E0E0)', null, 4.8, 2100, 6200, 29000),
  ('74', 'Original Blending Sponge', 'BEAUTYBLENDER', 'Tools', 'PKR 2,600', 2600, null, 100, 'The iconic pink egg sponge for flawless, streak-free blending', '🫧', 'linear-gradient(135deg,#FCE4EC,#F48FB1)', 'icon', 4.7, 5400, 17000, 71000)
on conflict (id) do nothing;
